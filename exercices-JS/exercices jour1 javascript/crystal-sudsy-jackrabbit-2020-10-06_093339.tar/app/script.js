/**
 * Créer un programme qui demande à l'utilisateur la température et lui affiche soit "Il faut chaud", soit "Il fait froid"
 */
let temperateur = Number ( prompt(" quelle température fait-il ?"));

if (temperateur >= 20){
  alert ("il fait chaud");
}

else {
alert("il fait froid")} ;
