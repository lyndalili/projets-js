/**
 * Créer un programme qui demande à l'utilisateur son âge puis lui afficher soit "Tu as {age} ans" soit "Ce n'est pas possible, tu ne peux pas avoir {age} ans !"
 */

"use strict";


let yourInformation = Number ( prompt ("tu as quelle age? "));

if (yourInformation <=100 >=1){
  alert("tu as" +yourInformation+ "ans");
}
else{
  alert("ce n'est pas possible, tu ne peux pas avoir" +yourInformation + "ans !")
}

