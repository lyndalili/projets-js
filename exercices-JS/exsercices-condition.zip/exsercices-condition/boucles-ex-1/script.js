
let git= (prompt("qu'elle est la commande git que vous cherchez?")); 


 if (git==="git configt"){
    alert("cette commande s'utilise pour configurer les préférences de l’utilisateur : son mail, l’algorithme utilisé pour diff, le nom d’utilisateur et le format de fichier etc. Par exemple, la commande suivante peut être utilisée pour définir le mail d’un utilisateur")
}

else if (git==="git init"){
    alert("Cette commande est utilisée pour créer un nouveau dépôt GIT" )
}

else if (git==="Git add"){
    alert("La commande git add peut être utilisée pour ajouter des fichiers à l’index. Par exemple, la commande suivante ajoutera un fichier nommé temp.txt dans le répertoire local de l’index" )
}

else if (git==="git clone"){
    alert("La commande git clone est utilisée pour la vérification des dépôts. Si le dépôt se trouve sur un serveur distant, utilisez" )
}
else if (git=== "git-commit"){
    alert("Cette commande permet d'effectuer un commit")
}

else if (git==="git status"){
    alert("La commande git status affiche la liste des fichiers modifiés ainsi que les fichiers qui doivent encore être ajoutés ou validés.")
}


else if (git==="git push"){
alert("Git push est une autre commandes GIT de base. Un simple push envoie les modifications locales apportées à la branche principale associée")
}

else if (git==="git chekout"){
    
   alert(" La commande git checkout peut être utilisée pour créer des branches ou pour basculer entre elles. Par exemple nous allons créer une branche")
}
else if (git==="git remote"){
alert ("La commande git remote permet à un utilisateur de se connecter à un dépôt distant. La commande suivante répertorie les dépôts distants actuellement configurés")
}

else if (git==="git pull"){
alert ("Pour fusionner toutes les modifications présentes sur le dépôt distant dans le répertoire de travail local, la commande pull est utilisée. ")}


else {
alert ("Oop's, je ne connais pas cette commande !")}