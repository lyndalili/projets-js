//les boucles 

"use strict";
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log

//au lieu de recrire plusieur fois on utilise une boucle 
for ( let i=0; i<10000; i++){
    console.log("bonjour");
}

//cree une variable i=0 le code dans laccolade sexcute 10000 fois i++ cest une acrementation , dans le cas ou  i++ est plus petit que 10000 il va continuer a sexcuter 
//dans le cas ou on veut faire aficher des numero on met console.log (i);

//si on veut aller jusqu'a 10000 on ecrit  for ( let i=0; i<=10000; i++){   console.log("bonjour");}

//initialisation let i=0
//verification de la condition  i<10000; i++) genre i++ si il est toujours inferieur a 10000
//si la consition est verifier execution du code   console.log("bonjour");
//une fois le code est verifier ca va incrementer 



//excercices
/**
 * Créer un programme qui demande à l'utilisateur un nombre puis compte de 1 en 1 jusqu'à ce nombre.
 * Par exemple, quand l'utilisateur tape 3, effectuer une alerte qui dit "1" puis une alerte qui dit "2" puis une alerte qui dit "3"
 */

let calcul= Number (prompt("quel est ton chiffre?"));
for (let i=0 ; i <=calcul ; i++ ){
    alert (i);
}


/**
 * Créer un programme qui demande à l'utilisateur un nombre de départ et un nombre d'arrivée puis compte de 1 en 1 du nombre de départ jusqu'au nombre d'arrivé.
 * Par exemple, quand l'utilisateur tape 100 et 103, effectuer une alerte qui dit "100" puis une alerte qui dit "101" puis une alerte qui dit "102"
 */

let nmbrdepart= Number(prompt("nombre de depart?"));
let nmbrarriver=Number(prompt("nombre de d'arriver?"));

for (let i= nmbrdepart; i <=nmbrarriver; i++){
alert (i);
}

/**
 * Créer un programme qui demande un nombre puis affiche dans la console la table de multiplication correspondante (jusqu'à 10)
 * Par exemple, si l'utilisateur tape 5, afficher :
 * 0 x 5 = 0
 * 1 x 5 = 5
 * 2 x 5 = 10
 * 3 x 5 = 15
 * 4 x 5 = 20
 * 5 x 5 = 25
 * 6 x 5 = 30
 * 7 x 5 = 35
 * 8 x 5 = 40
 * 9 x 5 = 45
 * 10 x 5 = 50
 */


let multiplication  = Number (prompt("Entrer un chiffre"));
for (let i = 0; i <= 10; i++) {
alert (multiplication + " x " + i + " = "+ multiplication*i);
}

/**
 * Créer un programme qui permet à l'utilisateur d'obtenir des nombres aléatoires.
 * Par exemple, quand l'utilisateur demande 3 nombres aléatoires, le programme lui affiche 5, 20, 11 (trois nombres générés aléatoirement)
 */
let nmbrrandom= Number(prompt("donnez un nombre?"));
for(var i = 0; i < nmbrrandom; i ++){
alert ( Math.floor(Math.random() *50));
}

/**
 * Créer un programme qui demande à l'utilisateur 5 nombres puis lui affiche le nombre le plus grand.
 * Scénarios :
 * - Quand l'utilisateur tape les nombres 3 5 -10 9 5, le programme lui affiche 9
 */

let nmbr= Number(prompt("1er nombre?"));
let nmbr1= Number(prompt("2e nombre?"));
let nmbr2=Number(prompt("3e nombre?"));
let nmbr3= Number(prompt("4e nombre?"));
let nmbr4=Number(prompt("5 nombre?"));
{
alert (Math.max(nmbr, nmbr1,nmbr2,nmbr3, nmbr4));
}


/**
 * Créer un programme qui demande à l'utilisateur 5 nombres puis lui affiche le nombre le plus petit.
 * Scénarios :
 * - Quand l'utilisateur tape les nombres 3 5 -10 9 5, le programme lui affiche -10
 */

let nmbr= Number(prompt("1er nombre?"));
let nmbr1= Number(prompt("2e nombre?"));
let nmbr2=Number(prompt("3e nombre?"));
let nmbr3= Number(prompt("4e nombre?"));
let nmbr4=Number(prompt("5 nombre?"));
{
alert (Math.min(nmbr, nmbr1,nmbr2,nmbr3, nmbr4));
}


/**
 * Voici un tableau contenant des noms de couleur. À l'aide d'une boucle, afficher dans la console le nom de chaque couleur.
 */

const colors = ['rouge', 'bleu', 'vert', 'orange', 'violet', 'jaune'];


const colors = ['rouge', 'bleu', 'vert', 'orange', 'violet', 'jaune'];
for (const color of colors){
    alert(color);
}

/**
 * Voici un tableau contenant des noms de couleur. À l'aide d'une boucle, afficher dans la console le nombre de lettres que comporte chaque couleur :
 * La couleur rouge comporte 5 lettres
 * La couleur bleu comporte 4 lettres
 * ...
 */

const colors = ['rouge', 'bleu', 'vert', 'orange', 'violet', 'jaune'];

const colors = ['rouge', 'bleu', 'vert', 'orange', 'violet', 'jaune'];

const arrayLength = colors.length;
console.log (arrayLength)
for (var i = 0; i < arrayLength; i++) {
    alert (colors[i].length);
}

/**
 * Voici un tableau contenant les noms des planètes du système solaire. À l'aide d'une boucle, afficher dans la console le nom de chaque planète ainsi que sa position.
 * Exemple :
 * La planète Mercure est en position 0
 * La planète Vénus est en position 1
 * La planète Terre est en position 2
 * La planète Mars est en position 3
 * ...
 */


const colors = ['Mercure', 'Vénus', 'Terre', 'Mars', 'Jupiter', 'Saturne', 'Uranus', 'Neptune'];

for (i=0; i<colors.length;i++){
console.log(i);}




/**
 * Créer un programme qui permet à l'utilisateur de connaître les x premières lettres de l'alphabet
 * Scénarios :
 * - Quand l'utilisateur tape 5, le programme affiche a puis b puis c puis d puis e puis f
 * - Quand l'utilisateur tape 30, le programme lui affiche une erreur lui indiquant qu'il n'y a que 26 lettres dans l'alphabet
 * - Quand l'utilisateur tape un nombre négatif, le programme lui affiche une erreur lui indiquant qu'il faut donner un nombre positif compris entre 1 et 26
 * - - Quand l'utilisateur tape 0, le programme lui affiche une erreur lui indiquant qu'il faut donner un nombre positif compris entre 1 et 26
 */



const alphabet = [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L","M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
 let namberOfLetter= Number (prompt ("donne moi un numero"));

 if (namberOfLetter > 26 ){
    alert ("erreur 'il n'y a que 26 lettres dans l'alphabet'")
}
 if (namberOfLetter <=0 ){
    alert ("il faut donner un nombre positif compris entre 1 et 26")

}

else {
 for (i=0; i<namberOfLetter;i++){
 alert(alphabet[i]);
}
}