//Créer un programme qui demande à l'utilisateur sa taille en cm puis lui dit s'il est grand ou petit

let mesure= Number (prompt("combien mesurez-vous en cm?"));

if (mesure >= 160){
  alert( "vous-etes petit !")
  }else{
      ("vous etes grand!")
  }


//   Créer un programme qui demande à l'utilisateur sa taille en cm puis lui dit s'il est très petit, petit, grand ou très grand
  let mesure= Number (prompt("combien mesurez-vous?"));

if (mesure <= 130 ) {
   alert( "vous-etes tres petit !")
  }else if  ( mesure <=160){
    alert ("vous etes petit!")
  }else if (mesure <180){
   alert ("vous etes grand!")
}else if ( mesure >=180){
  alert ( "vous etes tres grand!")
}