//les boucles 

"use strict";
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log
console.log

//au lieu de recrire plusieur fois on utilise une boucle 
for ( let i=0; i<10000; i++){
    console.log("bonjour");
}

//cree une variable i=0 le code dans laccolade sexcute 10000 fois i++ cest une acrementation , dans le cas ou  i++ est plus petit que 10000 il va continuer a sexcuter 
//dans le cas ou on veut faire aficher des numero on met console.log (i);

//si on veut aller jusqu'a 10000 on ecrit  for ( let i=0; i<=10000; i++){   console.log("bonjour");}

//initialisation let i=0
//verification de la condition  i<10000; i++) genre i++ si il est toujours inferieur a 10000
//si la consition est verifier execution du code   console.log("bonjour");
//une fois le code est verifier ca va incrementer 



//excercices
/**
 * Créer un programme qui demande à l'utilisateur un nombre puis compte de 1 en 1 jusqu'à ce nombre.
 * Par exemple, quand l'utilisateur tape 3, effectuer une alerte qui dit "1" puis une alerte qui dit "2" puis une alerte qui dit "3"
 */

let calcul= Number (prompt("quel est ton chiffre?"));
for (let i=0 ; i <=calcul ; i++ ){
    alert (i);
}


/**
 * Créer un programme qui demande à l'utilisateur un nombre de départ et un nombre d'arrivée puis compte de 1 en 1 du nombre de départ jusqu'au nombre d'arrivé.
 * Par exemple, quand l'utilisateur tape 100 et 103, effectuer une alerte qui dit "100" puis une alerte qui dit "101" puis une alerte qui dit "102"
 */

let calcul1=(prompt("nombre de depart?"));



for (let i=0; calcul1<=calcul2; i++){
alert ( calcul1<=calcul2);
}

let calcul2=(prompt("nombre de d'arriver?"));

for (let i=0; calcul1<=calcul2; i++){
    alert ( calcul1<=calcul2);
    }