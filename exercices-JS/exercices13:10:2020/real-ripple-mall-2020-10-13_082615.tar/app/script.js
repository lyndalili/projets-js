let sentancetext = prompt("what is your sentance? " );
 

let documentDiv = document.querySelector(".sentence");
document.querySelector (".sentence").textContent = sentancetext.toUpperCase()+  "!!!"; 