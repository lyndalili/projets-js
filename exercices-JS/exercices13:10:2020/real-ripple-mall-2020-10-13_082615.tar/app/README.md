# Modifier le contenu texte d'un élément HTML en Javascript

## Objectif
1. À l'aide de la fonction `prompt`, demander à l'utilisateur du texte
1. Afficher ce texte en contenu de l'élément ayant la classe `.sentence`, tout en majuscule et suivi de 3 points d'exclamation. 