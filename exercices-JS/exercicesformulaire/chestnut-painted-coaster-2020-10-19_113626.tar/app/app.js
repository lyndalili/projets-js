"use strict";

// Remplace la valeur du champ `prenom` du formulaire ayant le nom `superFormulaire` par "Mary"
let valeurDuChampPrenom= document.forms.superFormulaire.elements.prenom.value="mary";
console.log(valeurDuChampPrenom);

// Remplace la valeur du champ `adresseEmail` du formulaire ayant le nom `superFormulaire` par "mary@example.com"
