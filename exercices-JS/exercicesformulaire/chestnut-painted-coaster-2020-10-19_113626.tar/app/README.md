# Je sais...
Modifier la valeur d'un champ de formulaire

## Objectif
Suivre les indications dans le fichier `app.js`.